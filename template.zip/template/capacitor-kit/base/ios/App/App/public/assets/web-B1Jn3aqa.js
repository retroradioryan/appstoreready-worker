import { W as WebPlugin } from "./index-BKoDj5N3.js";
class SplashScreenWeb extends WebPlugin {
  async show(_options) {
    return void 0;
  }
  async hide(_options) {
    return void 0;
  }
}
export {
  SplashScreenWeb
};
